Input - Static text values that represent the user's name, degree program, and school make up the input. Expo and the React Native framework are used to develop the mobile application. StyleSheet is an object that allows the user to specify styles like font weight, text alignment, and background color.

Process - To develop the mobile application, Codespaces and Expo are used to set up the React Native environment.  While Text components show the user's name, degree program, and school, a View component acts as a container.  The yellow background, bold text, and centered alignment are defined by the StyleSheet.  Lastly, npx expo start is used to launch the application, and Expo Go is used to display it on a mobile device.


Output - The output is a mobile application that displays the user’s name, degree program, and school in bold, black text on a yellow background, centered on the screen.


